<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB; 
use Illuminate\Support\Facades\Mail; 
use App\Models\Opportunity;           
use App\Models\Application;          
use App\Mail\OpportunityApplicationMail;

class ApplicationController extends Controller
{
    public function index()
    {
        $applications = DB::table('applications')
        ->join('opportunities', 'applications.opportunity_id', '=', 'opportunities.id')
        ->where('applications.student_id', Auth::id())
        ->whereNull('applications.deleted_at') // Filters out the "removed" records
        ->select('applications.*', 'opportunities.title', 'opportunities.company_name', 'opportunities.type')
        ->orderBy('applications.created_at', 'desc')
        ->get();

        return view('student.applications', compact('applications'));
    }

    public function apply(Request $request, $id)
    {
        $opportunity = Opportunity::findOrFail($id);

        // Redirect warn
        if (!$opportunity->hr_email && $opportunity->application_link) {
            return view('student.redirection_warning', [
                'link' => $opportunity->application_link,
                'title' => $opportunity->title
            ]);
        }

        // Validate
        $request->validate([
            'q1_answer' => 'required|string|min:10|max:5000',
            'q2_answer' => 'required|string|min:10|max:5000',
            'cv'        => 'required|file|mimes:pdf|max:2048', 
        ]);

        // Check if already applied
        $existingApplication = Application::where('opportunity_id', $id)
            ->where('student_id', Auth::id())
            ->exists();
        if ($existingApplication) {
            return back()->with('error_app', 'You have already applied for this opportunity.');
        }

        // CV upload
        $path = $request->file('cv')->store('cvs', 'public');

        // Save app
        $application = Application::create([
            'opportunity_id' => $id,
            'student_id'     => Auth::id(),
            'q1_answer'      => $request->q1_answer,
            'q2_answer'      => $request->q2_answer,
            'cv_path'        => $path,
        ]);

        // Send email to HR
        if ($opportunity->hr_email) {
            Mail::to($opportunity->hr_email)->send(new OpportunityApplicationMail($application));
        }

        return back()->with('success_app', 'Your application was submitted successfully and sent to '  . $opportunity->hr_email);
    }

   public function trackExternal(Request $request, $id) {
    // Check if user wants to track opp
    if ($request->has('track_application')) {
        
        // Check if already applied
        $existing = Application::where('opportunity_id', $id)
            ->where('student_id', Auth::id())
            ->exists();

        if (!$existing) {
            Application::create([
                'opportunity_id' => $id,
                'student_id'     => Auth::id(),
                'q1_answer'      => 'External',
                'q2_answer'      => 'Redirection',
                'cv_path'        => 'link',
            ]);
        }
    }

    $opportunity = Opportunity::findOrFail($id);

    // Redirect to external
    return redirect()->away($opportunity->application_link);
}

public function destroy($id)
{
    DB::table('applications')
        ->where('id', $id)
        ->where('student_id', Auth::id())
        ->update(['deleted_at' => now()]);

    return back()->with('success_app', 'Application removed from your dashboard.');
}
}