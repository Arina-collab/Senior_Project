<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Applications | AUBG Portal</title>
    <link rel="stylesheet" href="{{ asset('css/Applications.css') }}">
</head>
<body>

<div class="sidebar">
    <h2>AUBG Portal</h2>
    <p>Welcome, <strong>{{ auth()->user()->email }}</strong></p>
    <nav>
        <a href="{{ route('profile.setup') }}">🏠 Profile</a>
        <a href="{{ route('opportunities.index') }}">📢 Opportunities</a>
        <a href="{{ route('applications.index') }}">💼 Applications</a>
        <a href="#">🔔 Notifications</a>
        <hr>
        <form action="{{ route('logout_btn') }}" method="POST">
            @csrf
            <button type="submit" class="logout-link">Log Out</button>
        </form>
    </nav>
</div>

<div class="main-content">
    <div class="welcome-header">
        <h1>Application Dashboard</h1>
        <p>Keep track of your career journey and pending submissions.</p>
    </div>

    <table class="app-table">
        <thead>
            <tr>
                <th>Opportunity</th>
                <th>Company</th>
                <th>Type</th>
                <th>Date Applied</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            @forelse($applications as $app)
                <tr>
                    <td><strong>{{ $app->title }}</strong></td>
                    <td>🏢 {{ $app->company_name }}</td>
                    <td><span class="opp-badge">{{ $app->type }}</span></td>
                    <td>{{ \Carbon\Carbon::parse($app->created_at)->format('M d, Y') }}</td>
                    <td>
                        @if($app->cv_path === 'link')
                            <span class="status-pill status-external">External</span>
                        @else
                            <span class="status-pill status-pending">Pending Review</span>
                        @endif
                    </td>
                    <td>
                    <form action="{{ route('applications.destroy', $app->id) }}" method="POST" 
                          onsubmit="return confirm('Are you sure you want to remove this application from your dashboard? This will not withdraw your application from the employer.')">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="delete-btn">
                            Remove
                        </button>
                    </form>
                </td>
                </tr>
            @empty
                <tr>
                    <td colspan="5" style="text-align: center; padding: 40px; color: #999;">
                        You haven't applied to any opportunities yet. 
                        <br><a href="{{ route('opportunities.index') }}" style="color: #003366;">Browse Opportunities</a>
                    </td>
                </tr>
            @endforelse
        </tbody>
    </table>
</div>
</body>
</html>