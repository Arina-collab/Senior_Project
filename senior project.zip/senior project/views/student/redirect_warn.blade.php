<div class="main-content" style="text-align: center; padding: 50px;">
    <div class="welcome-header">
        <h1>Leaving AUBG Portal</h1>
        <p>You are being redirected to an external application platform for: <strong>{{ $title }}</strong></p>
    </div>

    <div style="background: white; padding: 30px; border-radius: 8px; display: inline-block; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
        <p>This organization manages applications on their own website. Your data on this portal will not be shared with them automatically.</p>
        
        <div style="margin-top: 20px;">
            <a href="{{ $link }}" class="apply-btn-trigger" style="text-decoration: none; padding: 15px 30px;">
                Continue to Application ↗
            </a>
        </div>
        
        <div style="margin-top: 15px;">
            <a href="{{ route('opportunities.index') }}" style="color: #666; font-size: 14px;">Go Back</a>
        </div>
    </div>
</div>

<script>
    // Auto-redirect after 5 seconds
    setTimeout(function() {
        window.location.href = "{{ $link }}";
    }, 5000);
</script>