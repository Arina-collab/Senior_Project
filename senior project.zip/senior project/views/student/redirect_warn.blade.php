<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Opportunities | AUBG Portal</title>
    <link rel="stylesheet" href="{{ asset('css/Redirect_warn.css') }}">
    <meta name="base-url" content="{{ url('/') }}">
</head>
<body>

<div class="main-content redirect-container"> <div class="welcome-header">
        <h1>Leaving AUBG Portal</h1>
        <p>You are being redirected to an external application platform for: <strong>{{ $opportunity->title }}</strong></p>
        <p>Company: <strong>{{ $opportunity->company_name }}</strong></p>
    </div>

    <div class="redirect-card"> <p>This organization manages applications on their own website. Your data on this portal will not be shared with them automatically.</p>
        
        <div>
            <a href="{{ $opportunity->application_link }}" class="apply-btn-trigger redirect-external-btn"> Continue to Application ↗
            </a>
        </div>
        
        <div>
            <a href="{{ route('opportunities.index') }}" class="redirect-back-link"> Go Back
            </a>
        </div>
    </div>
</div>

<script>
    // Auto-redirect after 15 seconds
    setTimeout(function() {
        window.location.href = "{{ $opportunity->application_link }}";
    }, 15000);
</script>
</body>
</html>