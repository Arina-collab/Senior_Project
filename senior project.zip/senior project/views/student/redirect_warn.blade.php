<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Opportunities | AUBG Portal</title>
    <link rel="stylesheet" href="{{ asset('css/Redirect_warn.css') }}">
    <meta name="base-url" content="{{ url('/') }}">
</head>
<body>

<div class="main-content redirect-container"> <div class="welcome-header">
        <h1>Leaving AUBG Portal</h1>
        <p>You are being redirected to an external application platform for: <strong>{{ $opportunity->title }}</strong></p>
        <p>Company: <strong>{{ $opportunity->company_name }}</strong></p>
    </div>

    <div class="redirect-card"> <p>This organization manages applications on their own website. Your data on this portal will not be shared with them automatically.</p>
    <form action="{{ route('applications.track', $opportunity->id) }}" method="POST" id="trackForm">
    @csrf
    <div >
        <label style="cursor: pointer;">
            <input type="checkbox" name="track_application" value="1">
            <span><strong>Add this to my Application Dashboard for future tracking.</strong></span>
        </label>
    </div>
    <div>
        <button type="submit" class="redirect-external-btn">
            Continue to Application ↗
        </button>
    </div>
    <div>
        <a href="{{ route('opportunities.index') }}" class="redirect-back-link"> Go Back </a>
    </div>
    </form>
    </div>
</div>
</body>
</html>