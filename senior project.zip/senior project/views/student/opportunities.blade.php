<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Opportunities | AUBG Portal</title>
    <link rel="stylesheet" href="{{ asset('css/Student_opportunities.css') }}">
    <meta name="base-url" content="{{ url('/') }}">
</head>
<body>

<div class="sidebar">
    <h2>AUBG Portal</h2>
    <p>Welcome, <strong>{{ auth()->user()->email }}</strong></p>
    <nav>
        <a href="{{ route('profile.setup') }}">🏠 Profile</a>
        <a href="#">🔔 Notifications</a>
        <a href="{{ route('opportunities.index') }}">📢 Opportunities</a>
        <a href="{{ route('applications.index') }}">💼 Applications</a>
        <a href="#">📅 Events</a>
        <a href="#">📄 Registrations</a>
        <a href="#">✅ Poster Approval</a>
        <hr>
        <form action="{{ route('logout_btn') }}" method="POST">
            @csrf
            <button type="submit" class="logout-link">Log Out</button>
        </form>
    </nav>
</div>

<div class="main-content">
    @if(session('success_app'))
        <div class="alert-success-banner">
            🎉 {{ session('success_app') }}
        </div>
    @endif

    @if(session('error_app'))
        <div class="alert-error-banner" style="background-color: #f8d7da; color: #721c24; padding: 15px; border-radius: 8px; margin-bottom: 20px; border: 1px solid #f5c6cb; text-align: center;">
            ⚠️ {{ session('error_app') }}
        </div>
    @endif

    <div class="welcome-header">
        <h1>Career Opportunities</h1>
        <p>Explore internships, jobs, and projects available for AUBG students.</p>
    </div>

    <div class="opportunities-wrapper">
        <aside class="filter-sidebar">
            <form action="{{ route('opportunities.index') }}" method="GET" class="filter-form">
                
                <div class="filter-group">
                    <label>Search by Keywords</label>
                    <input type="text" name="keyword" value="{{ request('keyword') }}" 
                           placeholder="e.g. Developer, Internship..." class="filter-input"
                           onkeypress="if(event.key === 'Enter') this.form.submit()">
                </div>
                
                <div class="filter-group">
                    <label>Category</label>
                    <select name="category" onchange="this.form.submit()" class="filter-select">
                        <option value="">All Categories</option>
                        @foreach($categories as $cat)
                            <option value="{{ $cat->name }}" {{ request('category') == $cat->name ? 'selected' : '' }}>
                                {{ $cat->name }}
                            </option>
                        @endforeach
                    </select>
                </div>

                <div class="filter-group">
                    <label>Location</label>
                    <input type="text" name="location" value="{{ request('location') }}" 
                           placeholder="Enter city or country..." class="filter-input" 
                           onkeypress="if(event.key === 'Enter') this.form.submit()">
                </div>

                <div class="filter-group">
                    <label class="filter-checkbox-label">
                        <input type="checkbox" name="aubg_priority" value="1" 
                               {{ request('aubg_priority') ? 'checked' : '' }} 
                               onchange="this.form.submit()">
                        AUBG Priority
                    </label>
                </div>

                @if(request()->anyFilled(['keyword', 'category', 'location', 'aubg_priority']))
                    <a href="{{ route('opportunities.index') }}" class="clear-filters">Clear All Filters</a>
                @endif
            </form>
        </aside>

        <main class="opportunities-main">
            <div class="opportunity-grid">
                @forelse($opportunities as $opp)
                    <div class="opp-card {{ $opp->is_priority ? 'priority' : '' }}">
                        <div class="card-top">
                            <div class="card-header">
                                <span class="opp-badge">{{ $opp->type }}</span>
                                @if($opp->is_priority)
                                    <span class="priority-label">⭐ Priority</span>
                                @endif
                            </div>
                            
                            <h3>{{ $opp->title }}</h3>
                            <p class="company-tag">🏢 <strong>{{ $opp->company_name }}</strong></p>
                            <p class="location-tag">📍 {{ $opp->location }} | {{ $opp->category }}</p>
                            <p class="deadline-text"><strong>Deadline:</strong> {{ $opp->deadline ?: 'No deadline set' }}</p>
                        </div>
                        
                        <div class="card-footer">
                            <small class="post-date">Posted {{ $opp->created_at->diffForHumans() }}</small>
                            <div class="btn-group">
                            <a href="{{ route('opportunities.show', $opp->id) }}" class="view-btn">Details</a>
    
                            @if($opp->hr_email)
                            <button type="button" class="apply-btn-trigger" onclick="openAppModal({{ $opp->id }}, '{{ addslashes($opp->title) }}')">
                            Apply
                            </button>
                            @elseif($opp->application_link)
                            <a href="{{ route('opportunities.redirect', $opp->id) }}" class="apply-btn-trigger">
                            Apply
                            </a>
                            @endif
                        </div>
                        </div>
                    </div>
                @empty
                    <div class="empty-state">
                        <p>No opportunities found matching your criteria.</p>
                    </div>
                @endforelse
            </div>

            <div class="pagination-wrapper">
                {{ $opportunities->appends(request()->query())->links() }}
            </div>
        </main>
    </div>
</div>

<div id="applicationModal" class="app-modal shadow-lg">
    <div class="app-modal-content">
        <div class="modal-header">
            <button onclick="closeAppModal()" class="close-btn">&times;</button>
            <h2 id="modalTitle">Apply for Opportunity</h2>
        </div>
        
        <form id="applyForm" action="" method="POST" enctype="multipart/form-data">
            @csrf
            <div class="form-group">
                <label>Why are you interested in this opportunity?</label>
                <textarea name="q1_answer" placeholder="Minimum 10 characters..." required></textarea>
            </div>

            <div class="form-group">
                <label>Briefly describe your relevant experience:</label>
                <textarea name="q2_answer" placeholder="Minimum 10 characters..." required></textarea>
            </div>

            <div class="form-group">
                <label>Upload your CV (PDF only, max 2MB)</label>
                <input type="file" name="cv" accept=".pdf" required>
            </div>

            <button type="submit" class="submit-app-btn">Submit Application</button>
        </form>
    </div>
</div>

<script>
    function openAppModal(id, title) {
        const modal = document.getElementById('applicationModal');
        const form = document.getElementById('applyForm');
        const titleElem = document.getElementById('modalTitle');
        form.action = "{{ url('/apply') }}/" + id;
        titleElem.innerText = "Apply for: " + title;
        modal.style.display = 'flex';
    }

    function closeAppModal() {
        document.getElementById('applicationModal').style.display = 'none';
    }

    window.onclick = function(event) {
        const modal = document.getElementById('applicationModal');
        if (event.target == modal) { closeAppModal(); }
    }
</script>

</body>
</html>