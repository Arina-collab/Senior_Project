<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - AUBG Portal</title>
    <link rel="stylesheet" href="{{ asset('css/Admin_home.css') }}">
</head>
<body>
    <div class="container">
        <div class="sidebar">
            <h2>AUBG Portal</h2>
            <nav>
                <a href="{{ route('admin.dashboard') }}" class="active">🛠 Admin Board</a>
                <hr>
                <form action="{{ route('logout_btn') }}" method="POST">
                    @csrf
                    <button type="submit" class="logout-btn">Log Out</button>
                </form>
            </nav>
        </div>

        <div class="main-content">
            <div class="welcome-header">
                <h1>Staff Authorization</h1>
                <p>Grant administrative or career center access to AUBG staff members.</p>
                
                @if(session('success'))
                    <div class="alert-success">
                        {{ session('success') }}
                    </div>
                @endif
            </div>

            <div class="admin-grid">
                <div class="form-card">
                    <h2>Add New Staff Member</h2>
                    <form action="{{ route('admin.authorize_staff') }}" method="POST">
                        @csrf
                        <div class="form-group">
                            <label for="email">AUBG Email</label>
                            <input type="email" name="email" id="email" class="form-control" value="{{ old('email') }}" required>
                            @error('email')
                                <span class="error-text">{{ $message }}</span>
                            @enderror
                        </div>

                        <div class="form-group">
                            <label for="role">Role</label>
                            <select name="role" id="role" class="form-control" required>
                                <option value="Career Center">Career Center</option>
                                <option value="Admin">Admin</option>
                            </select>
                            @error('role')
                                <span class="error-text">{{ $message }}</span>
                            @enderror
                        </div>

                        <button type="submit" class="btn-submit">Add Staff Member</button>
                    </form>
                </div>

                <div class="form-card category-management-section">
                    <div class="card-header">
                        <h2>Opportunity Categories for Approval</h2>
                        <p>Fix typos or approve new categories requested by the Career Center.</p>
                    </div>
                    
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>Category Name</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($new as $cat)
                            <tr>
                                <td>
                                    <form action="{{ route('admin.categories.update', $cat->id) }}" method="POST" class="inline-edit-form">
                                        @csrf
                                        @method('PATCH')
                                        <input type="text" name="name" value="{{ $cat->name }}" class="form-input">
                                        <button type="submit" class="btn-save">Save</button>
                                    </form>
                                </td>
                                <td>
                                    <div class="action-group">
                                        <form action="{{ route('admin.categories.approve', $cat->id) }}" method="POST">
                                            @csrf
                                            @method('PATCH')
                                            <button type="submit" class="btn-approve">Approve</button>
                                        </form>

                                        <form action="{{ route('admin.categories.destroy', $cat->id) }}" method="POST">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="btn-delete" onclick="return confirm('Permanently delete this category?')">Delete</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>

                    @if($new->isEmpty())
                        <p class="empty-state">No new categories to review.</p>
                    @endif
                </div>
            </div>
        </div>
    </div>
</body>
</html>