<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Opportunities | AUBG Portal</title>
    <link rel="stylesheet" href="{{ asset('css/Career_opportunities.css') }}">
    <meta name="base-url" content="{{ url('/') }}">
</head>
<body>

<div class="sidebar">
    <h2>AUBG Portal</h2>
    <nav>
        <a href="{{ route('opportunities.add') }}">📊 Add an opportunity</a>

        <a href="{{ route('career.dashboard') }}" class="active">📋 All Postings</a>
        
        <a href="#">🎓 Student Directory</a>
        <hr>
        <form action="{{ route('logout_btn') }}" method="POST">
            @csrf
            <button type="submit">Log Out</button>
        </form>
    </nav>
</div>

<div class="main-content">
    @if(session('success_app'))
        <div class="alert-success-banner">
            🎉 {{ session('success_app') }}
        </div>
    @endif

    @if(session('error_app'))
        <div class="alert-error-banner" style="background-color: #f8d7da; color: #721c24; padding: 15px; border-radius: 8px; margin-bottom: 20px; border: 1px solid #f5c6cb; text-align: center;">
            ⚠️ {{ session('error_app') }}
        </div>
    @endif

    <div class="welcome-header">
        <h1>Career Opportunities</h1>
        <p>Here are internships, jobs, and projects that are currently visible to AUBG students.</p>
    </div>

    <div class="top-search-bar">
        <form action="{{ route('career.dashboard') }}" method="GET" class="filter-form-horizontal">
            <div class="filter-group">
                <label>Search by Keywords</label>
                <div class="search-input-wrapper">
                    <input type="text" name="keyword" value="{{ request('keyword') }}" 
                           placeholder="Search title or company..." class="filter-input">
                    
                    <button type="submit" class="view-btn" style="height: 40px; border: none;">Search</button>

                    @if(request()->filled('keyword'))
                        <a href="{{ route('career.dashboard') }}" class="clear-filters">Clear All</a>
                    @endif
                </div>
            </div>
        </form>
    </div>

        <main class="opportunities-main">
            <div class="opportunity-grid">
                @forelse($opportunities as $opp)
                    <div class="opp-card {{ $opp->is_priority ? 'priority' : '' }}">
                        <div class="card-top">
                            <div class="card-header">
                                <span class="opp-badge">{{ $opp->type }}</span>
                                @if($opp->is_priority)
                                    <span class="priority-label">⭐ Priority</span>
                                @endif
                            </div>
                            
                            <h3>{{ $opp->title }}</h3>
                            <p class="company-tag">🏢 <strong>{{ $opp->company_name }}</strong></p>
                            <p class="location-tag">📍 {{ $opp->location }} | {{ $opp->category }}</p>
                            <p class="deadline-text"><strong>Deadline:</strong> {{ $opp->deadline ?: 'No deadline set' }}</p>
                            <small class="post-date">Posted {{ $opp->created_at->diffForHumans() }}</small>
                        </div>
                        
                        <div class="card-footer">
                            <div class="btn-group">
                            <a href="{{ route('opportunities.show', $opp->id) }}" class="view-btn">Details</a>
                            <a href="{{ route('opportunities.edit', $opp->id) }}" class="edit-btn">
                                Edit 
                            </a>
                            <form action="{{ route('opportunities.destroy', $opp->id) }}" method="POST" style="display:inline;">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="delete-btn" onclick="return confirm('Are you sure you want to delete this opportunity?')">
                                Delete 
                                </button>
                            </form>
                        </div>
                        </div>
                    </div>
                @empty
                    <div class="empty-state">
                        <p>No opportunities found matching your criteria.</p>
                    </div>
                @endforelse
            </div>

            <div class="pagination-wrapper">
                {{ $opportunities->appends(request()->query())->links() }}
            </div>
        </main>
    </div>
</div>

<div id="applicationModal" class="app-modal shadow-lg">
    <div class="app-modal-content">
        <div class="modal-header">
            <button onclick="closeAppModal()" class="close-btn">&times;</button>
            <h2 id="modalTitle">Apply for Opportunity</h2>
        </div>
        
        <form id="applyForm" action="" method="POST" enctype="multipart/form-data">
            @csrf
            <div class="form-group">
                <label>Why are you interested in this opportunity?</label>
                <textarea name="q1_answer" placeholder="Minimum 10 characters..." required></textarea>
            </div>

            <div class="form-group">
                <label>Briefly describe your relevant experience:</label>
                <textarea name="q2_answer" placeholder="Minimum 10 characters..." required></textarea>
            </div>

            <div class="form-group">
                <label>Upload your CV (PDF only, max 2MB)</label>
                <input type="file" name="cv" accept=".pdf" required>
            </div>

            <button type="submit" class="submit-app-btn">Submit Application</button>
        </form>
    </div>
</div>

<script>
    function openAppModal(id, title) {
        const modal = document.getElementById('applicationModal');
        const form = document.getElementById('applyForm');
        const titleElem = document.getElementById('modalTitle');
        form.action = "{{ url('/apply') }}/" + id;
        titleElem.innerText = "Apply for: " + title;
        modal.style.display = 'flex';
    }

    function closeAppModal() {
        document.getElementById('applicationModal').style.display = 'none';
    }

    window.onclick = function(event) {
        const modal = document.getElementById('applicationModal');
        if (event.target == modal) { closeAppModal(); }
    }
</script>

</body>
</html>