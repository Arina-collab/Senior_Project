<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Application;
use Illuminate\Http\Request;

class AnalyticsController extends Controller
{
    public function index()
    {
        // Count student users
        $totalStudents = User::where('role', 'Student')->count();

        // Count all submitted applications
        $totalApplications = Application::count();

        return view('career.analytics', compact('totalStudents', 'totalApplications'));
    }
}