<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Analytics - AUBG Portal</title>
    <link rel="stylesheet" href="{{ asset('css/Analytics.css') }}">
</head>
<body>
    <div class="sidebar">
        <h2>AUBG Portal</h2>
        <nav>
            <a href="{{ route('opportunities.add') }}">📁 Add an opportunity</a>
            <a href="{{ route('career.dashboard') }}">📄 All Postings</a>
            <a href="{{ route('career.analytics') }}" class="active">📊 Analytics</a>
            <hr>
            <form action="{{ route('logout_btn') }}" method="POST">
                @csrf
                <button type="submit" class="logout-btn">Log Out</button>
            </form>
        </nav>
    </div>

    <div class="main-content">
        <div class="welcome-header">
            <h1>Platform Analytics</h1>
            <p>Overview of student engagement and application activity.</p>
        </div>

        <div class="stats-container">
            <div class="stat-box">
                <h2>Total Students</h2>
                <p class="stat-number">{{ $totalStudents }}</p>
            </div>

            <div class="stat-box">
                <h2>Applications</h2>
                <p class="stat-number">{{ $totalApplications }}</p>
            </div>
        </div>
    </div>
</body>
</html>