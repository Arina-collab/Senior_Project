<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Analytics - AUBG Portal</title>
    <link rel="stylesheet" href="{{ asset('css/Analytics.css') }}">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="sidebar">
        <h2>AUBG Portal</h2>
        <nav>
            <a href="{{ route('opportunities.add') }}">📁 Add an opportunity</a>
            <a href="{{ route('career.dashboard') }}">📄 All Postings</a>
            <a href="{{ route('career.analytics') }}" class="active">📊 Analytics</a>
            <hr>
            <form action="{{ route('logout_btn') }}" method="POST">
                @csrf
                <button type="submit" class="logout-btn">Log Out</button>
            </form>
        </nav>
    </div>

    <div class="main-content">
        <div class="welcome-header">
            <h1>Platform Analytics</h1>
            <p>Overview of student engagement and application activity.</p>
        </div>

        <div class="stats-container">
            <div class="stat-box">
                <h2>Total Students</h2>
                <p class="stat-number">{{ $totalStudents }}</p>
            </div>

            <div class="stat-box">
                <h2>Applications</h2>
                <p class="stat-number">{{ $totalApplications }}</p>
            </div>
        </div>

        <div class="chart-controls">
            <button onclick="changeWeek(-1)" class="view-btn">Last Week</button>
            <button onclick="changeWeek(1)" class="view-btn">Next Week</button>
        </div>

        <div class="stat-box" style="margin-top: 20px;">
            <canvas id="activityChart"></canvas>
        </div>
    </div>

<script>
let currentOffset = 0;
let myChart;

function loadChart(offset) {
    fetch(`{{ route('career.chart_data') }}?offset=${offset}`)
        //JSON processing
        .then(response => response.json())
        .then(json => {
            const ctx = document.getElementById('activityChart').getContext('2d');
            
            // Calculate percentages based on total
            const percentageData = json.counts.map(count => 
                json.total > 0 ? ((count / json.total) * 100).toFixed(1) : 0
            );

            const chartOptions = {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true,
                        min: 0,
                        max: 100,
                        ticks: {
                            callback: function(value) {
                                return value + "%";
                            }
                        }
                    }
                },
                plugins: {
                    title: { display: true, text: json.title },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                // Retrieve the raw count
                                const count = json.counts[context.dataIndex];
                                return `${context.parsed.y}% (${count} students)`;
                            }
                        }
                    }
                }
            };

            if (myChart) {
                myChart.data.labels = json.labels;
                myChart.data.datasets[0].data = percentageData;
                myChart.options = chartOptions;
                myChart.update();
            } else {
                myChart = new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: json.labels,
                        datasets: [{
                            label: 'Student Engagement',
                            data: percentageData,
                            borderColor: '#003366',
                            backgroundColor: 'rgba(0, 51, 102, 0.1)',
                            fill: true,
                            tension: 0.4
                        }]
                    },
                    options: chartOptions
                });
            }
        });
}

function changeWeek(direction) {
    currentOffset += direction;
    loadChart(currentOffset);
}

// Initial load
loadChart(0);
</script>
</div>
</body>
</html>