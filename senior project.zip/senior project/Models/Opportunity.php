<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Opportunity extends Model
{
    protected $fillable = [
        'title',
        'company_name',
        'category',
        'type',
        'description',
        'location',
        'deadline',
        'is_priority',
        'posted_by',
        'hr_email',
        'application_link',
    ];

    public function publisher()
    {
        return $this->belongsTo(User::class, 'posted_by');
    }

    public function applications()
    {
        return $this->hasMany(Application::class);
    }  
}