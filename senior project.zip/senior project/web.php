<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProfileController; 
use App\Http\Controllers\AuthController;
use App\Http\Controllers\ForgotPasswordController;
use App\Http\Controllers\OpportunityController;
use App\Http\Controllers\StudentOpportunityController;
use App\Http\Controllers\ApplicationController;
use App\Http\Controllers\CareerOpportunitiesController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\AnalyticsController;

Route::get('/', fn() => view('Home'))->name('home');

// Auth routes
Route::post('/signup', [AuthController::class, 'signup'])->name('signup_btn');
Route::post('/login', [AuthController::class, 'login'])->name('login_btn');
Route::post('/logout', [AuthController::class, 'logout'])->name('logout_btn');

Route::middleware(['auth'])->group(function () {
    //Admin home page
    Route::middleware(['auth', 'role:Admin'])->group(function () {
        Route::get('/admin/dashboard', function () {
            return view('admin.Home');
        })->name('admin.dashboard');
        Route::post('/admin/authorize-staff', [AdminController::class, 'authorizeStaff'])
        ->name('admin.authorize_staff');
    });
    // Profile
    Route::get('/profile/setup', [ProfileController::class, 'show'])->name('profile.setup');
    Route::post('/profile/setup', [ProfileController::class, 'store'])->name('complete_profile_btn');
    Route::patch('/profile/update', [ProfileController::class, 'update'])->name('profile.update');

    // Student applications
    Route::post('/apply/{id}', [ApplicationController::class, 'apply'])->name('opportunity.apply');
    Route::get('/my-applications', [ApplicationController::class, 'index'])->name('applications.index');

    //Traking external
    Route::post('/applications/track/{id}', [ApplicationController::class, 'trackExternal'])
    ->name('applications.track');

    //Student soft delete app
    Route::delete('/my-applications/{id}', [ApplicationController::class, 'destroy'])
        ->name('applications.destroy');

    // Career center
    Route::middleware(['auth', 'role:Career Center'])->group(function () {
    
    // List, edit, update, delete
    Route::get('/career-center/all', [CareerOpportunitiesController::class, 'index'])
        ->name('career.dashboard');

    // Add opps
    Route::get('/career-center/add', [OpportunityController::class, 'index'])
        ->name('opportunities.add');
        
    //Store opps 
    Route::post('/action/opportunities', [OpportunityController::class, 'store'])
        ->name('opportunities.store');

    // Managing opps
    Route::resource('action/opportunities', CareerOpportunitiesController::class)
        ->except(['index', 'store'])
        ->names([
            'show'    => 'opportunities.show',
            'edit'    => 'opportunities.edit',
            'update'  => 'opportunities.update',
            'destroy' => 'opportunities.destroy',
        ]);
    
    //Analytics
    Route::get('/career-center/analytics', [AnalyticsController::class, 'index'])
    ->name('career.analytics');});
});

// Student view read-only
Route::get('/opportunities', [StudentOpportunityController::class, 'index'])->name('opportunities.index');
Route::get('/opportunities/{id}', [StudentOpportunityController::class, 'show'])->name('student.opportunities.show');
Route::get('/opportunities/{id}/redirect', [StudentOpportunityController::class, 'showRedirectWarning'])->name('opportunities.redirect');

// Pass reset
Route::get('forgot-password', [ForgotPasswordController::class, 'showLinkRequestForm'])->name('password.request');
Route::post('forgot-password', [ForgotPasswordController::class, 'sendResetLinkEmail'])->name('password.email');
Route::post('reset-password', [ForgotPasswordController::class, 'resetPassword'])->name('password.update');
Route::get('reset-password/{token}', fn($token) => view('auth.reset-password', ['token' => $token]))->name('password.reset');