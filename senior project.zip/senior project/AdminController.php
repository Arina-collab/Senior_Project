<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Authorizedstaff;
use App\Models\User;

class AdminController extends Controller
{
    public function authorizeStaff(Request $request)
    {
        // Validate
        $validated = $request->validate([
            'email' => 'required|email|regex:/^[a-zA-Z0-9.]+@aubg\.edu$/|unique:authorized_staff',
            'role'  => 'required|string', 
        ]);

        // Save to Db
        Authorizedstaff::create([
            'email' => $validated['email'],
            'role'  => $validated['role'],
        ]);

        // Go back with a success msg
        return redirect()->back()->with('success', 'Staff member added successfully!');
    }
}