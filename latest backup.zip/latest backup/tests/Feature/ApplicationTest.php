<?php

namespace Tests\Feature;

use App\Models\Application;
use App\Models\Opportunity;
use App\Models\User;
use App\Mail\OpportunityApplicationMail;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Storage;
use Tests\TestCase;

class ApplicationControllerTest extends TestCase
{
    use RefreshDatabase;

    protected $student;

    protected function setUp(): void
    {
        parent::setUp();
        $this->student = User::factory()->create();
    }

    /** @test */
    public function view_apps()
    {
        $opportunity = Opportunity::factory()->create(['title' => 'Test Job']);

        Application::factory()->create([
            'student_id' => $this->student->id,
            'opportunity_id' => $opportunity->id
        ]);

        $response = $this->actingAs($this->student)
                         ->get(route('applications.index'));

        $response->assertStatus(200);
        $response->assertViewIs('student.applications');
        $response->assertSee('Test Job');
    }

    /** @test */
    public function apply_internally()
    {
        Mail::fake();
        Storage::fake('public');

        $opportunity = Opportunity::factory()->create([
            'hr_email' => 'recruiter@example.com'
        ]);

        $file = UploadedFile::fake()->create('resume.pdf', 500, 'application/pdf');

        $formData = [
            'q1_answer' => 'This is a valid answer for question one.',
            'q2_answer' => 'This is another valid answer for question two.',
            'cv' => $file,
        ];

        $response = $this->actingAs($this->student)
                         ->post(route('opportunity.apply', $opportunity->id), $formData);

        $response->assertSessionHas('success_app');
        
        $this->assertDatabaseHas('applications', [
            'student_id' => $this->student->id,
            'opportunity_id' => $opportunity->id,
        ]);

        $application = Application::where('student_id', $this->student->id)->first();
        Storage::disk('public')->assertExists($application->cv_path);

        Mail::assertSent(OpportunityApplicationMail::class, function ($mail) use ($opportunity) {
            return $mail->hasTo('recruiter@example.com');
        });
    }

    /** @test */
    public function fail_validation()
    {
        $opportunity = Opportunity::factory()->create(['hr_email' => 'hr@test.com']);
        
        $response = $this->actingAs($this->student)
                         ->post(route('opportunity.apply', $opportunity->id), [
                             'q1_answer' => 'short',
                             'q2_answer' => 'too short',
                             'cv' => UploadedFile::fake()->create('resume.pdf')
                         ]);

        $response->assertSessionHasErrors(['q1_answer', 'q2_answer']);
    }

    /** @test */
    public function duplicate_apps()
    {
        $opportunity = Opportunity::factory()->create(['hr_email' => 'hr@test.com']);
        
        Application::factory()->create([
            'student_id' => $this->student->id,
            'opportunity_id' => $opportunity->id
        ]);

        $response = $this->actingAs($this->student)
                         ->post(route('opportunity.apply', $opportunity->id), [
                             'q1_answer' => 'Valid long answer for q1',
                             'q2_answer' => 'Valid long answer for q2',
                             'cv' => UploadedFile::fake()->create('resume.pdf')
                         ]);

        $response->assertSessionHas('error_app', 'You have already applied for this opportunity.');
    }

    /** @test */
    public function external_warning_if_no_hr_email()
    {
        $opportunity = Opportunity::factory()->create([
            'hr_email' => null,
            'application_link' => 'https://external-job.com'
        ]);

        $response = $this->actingAs($this->student)
                         ->post(route('opportunity.apply', $opportunity->id));

        $response->assertViewIs('student.redirection_warning');
        $response->assertViewHas('link', 'https://external-job.com');
    }

    /** @test */
    public function track_external_app_and_redirect()
    {
        $opportunity = Opportunity::factory()->create([
            'application_link' => 'https://external-site.com'
        ]);

        $response = $this->actingAs($this->student)
                         ->post(route('applications.track', $opportunity->id), [
                             'track_application' => 'on'
                         ]);

        $response->assertRedirect('https://external-site.com');
        
        $this->assertDatabaseHas('applications', [
            'student_id' => $this->student->id,
            'opportunity_id' => $opportunity->id,
            'q1_answer' => 'External'
        ]);
    }
}