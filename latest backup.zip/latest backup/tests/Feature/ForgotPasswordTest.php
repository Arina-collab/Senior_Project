<?
namespace Tests\Feature;

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Notification;
use Illuminate\Support\Facades\Password;
use Illuminate\Auth\Notifications\ResetPassword;
use Tests\TestCase;

class ForgotPasswordControllerTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function send_reset_link_to_valid_user()
    {
        Notification::fake();
        $user = User::factory()->create(['email' => 'student123@aubg.edu']);

        $response = $this->post(route('password.email'), [
            'email' => 'student123@aubg.edu',
        ]);

        $response->assertSessionHas('status');
        Notification::assertSentTo($user, ResetPassword::class);
    }

    /** @test */
    public function fails_if_the_email_is_not_in_the_database()
    {
        $response = $this->post(route('password.email'), [
            'email' => 'stranger@gmail.com',
        ]);

        $response->assertSessionHasErrors(['email']);
    }

    /** @test */
    public function reset_password_with_valid_token()
    {
        $user = User::factory()->create([
            'email' => 'student123@aubg.edu',
            'password' => Hash::make('OldPassword123!'),
        ]);

        // Generate a valid token for this user
        $token = Password::broker()->createToken($user);

        $response = $this->post(route('password.update'), [
            'token' => $token,
            'email' => 'student123@aubg.edu',
            'password' => 'NewSecurePass123!',
            'password_confirmation' => 'NewSecurePass123!',
        ]);

        $response->assertRedirect(route('home'));
        $response->assertSessionHas('status');

        // Check if password was changed in the DB
        $this->assertTrue(Hash::check('NewSecurePass123!', $user->refresh()->password));
    }

    /** @test */
    public function fail_if_token_is_invalid()
    {
        $user = User::factory()->create(['email' => 'student123@aubg.edu']);

        $response = $this->post(route('password.update'), [
            'token' => 'invalid-token',
            'email' => 'student123@aubg.edu',
            'password' => 'NewSecurePass123!',
            'password_confirmation' => 'NewSecurePass123!',
        ]);

        $response->assertSessionHasErrors(['email']);
        $this->assertFalse(Hash::check('NewSecurePass123!', $user->refresh()->password));
    }

    /** @test */
    public function fail_if_passwords_dont_match()
    {
        $user = User::factory()->create(['email' => 'student123@aubg.edu']);
        $token = Password::broker()->createToken($user);

        $response = $this->post(route('password.update'), [
            'token' => $token,
            'email' => 'student123@aubg.edu',
            'password' => 'NewSecurePass123!',
            'password_confirmation' => 'DifferentPassword',
        ]);

        $response->assertSessionHasErrors(['password']);
    }

    /** @test */
    public function fail_if_password_too_short()
    {
        $user = User::factory()->create(['email' => 'student123@aubg.edu']);
        $token = Password::broker()->createToken($user);

        $response = $this->post(route('password.update'), [
            'token' => $token,
            'email' => 'student123@aubg.edu',
            'password' => '123', // Below min:6
            'password_confirmation' => '123',
        ]);

        $response->assertSessionHasErrors(['password']);
    }
}