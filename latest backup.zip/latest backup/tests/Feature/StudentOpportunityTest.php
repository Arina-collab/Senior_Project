<?php

namespace Tests\Feature;

use App\Models\Opportunity;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Tests\TestCase;

class StudentOpportunityTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        DB::table('opportunity_categories')->insert([
            ['name' => 'IT'],
            ['name' => 'Business']
        ]);
    }

    /** @test */
    public function display_index()
    {
        Opportunity::factory()->create(['title' => 'Software Intern']);

        $response = $this->get(route('opportunities.index'));

        $response->assertStatus(200);
        $response->assertViewIs('student.opportunities');
        $response->assertViewHasAll(['opportunities', 'categories']);
        $response->assertSee('Software Intern');
    }

    /** @test */
    public function search_by_keyword()
    {
        Opportunity::factory()->create(['title' => 'Matching Job', 'description' => 'Laravel dev']);
        Opportunity::factory()->create(['title' => 'Hidden Job', 'description' => 'Other']);

        $response = $this->get(route('opportunities.index', ['keyword' => 'Matching']));

        $response->assertSee('Matching Job');
        $response->assertDontSee('Hidden Job');
    }

    /** @test */
    public function filter_aubg_priority()
    {
        Opportunity::factory()->create(['title' => 'Priority Job', 'is_priority' => true]);
        Opportunity::factory()->create(['title' => 'Normal Job', 'is_priority' => false]);

        $response = $this->get(route('opportunities.index', ['aubg_priority' => 'on']));

        $response->assertSee('Priority Job');
        $response->assertDontSee('Normal Job');
    }

    /** @test */
    public function error_if_opp_does_not_exist()
    {
        $response = $this->get(route('student.opportunities.show', 999));

        $response->assertStatus(404);
    }

    /** @test */
    public function redirect_warning()
    {
        $opportunity = Opportunity::factory()->create();

        $response = $this->get(route('opportunities.redirect', $opportunity->id));

        $response->assertStatus(200);
        $response->assertViewIs('student.redirect_warn');
        $response->assertViewHas('opportunity');
    }

    /** @test */
    public function empty_search_results()
    {
        $response = $this->get(route('opportunities.index', ['keyword' => 'NonExistentTitle']));

        $response->assertStatus(200);
        $response->assertViewHas('categories');
    }
}