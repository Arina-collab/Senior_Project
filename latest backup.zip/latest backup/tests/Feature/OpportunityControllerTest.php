<?
namespace Tests\Feature;

use App\Models\User;
use App\Models\Opportunity;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Tests\TestCase;

class OpportunityControllerTest extends TestCase
{
    use RefreshDatabase;

    protected $careerStaff;

    protected function setUp(): void
    {
        parent::setUp();
        // Setup a Career Center staff member
        $this->careerStaff = User::factory()->create(['role' => 'Career Center']);
    }
    
    /** @test */
    public function display_dashboard_with_categories_and_posts()
    {
        // Seed a category
        DB::table('opportunity_categories')->insert(['name' => 'Internship']);

        // Create a post
        Opportunity::create([
            'title' => 'Software Intern',
            'category' => 'Internship',
            'type' => 'Full-time',
            'description' => 'Great role',
            'location' => 'Blagoevgrad',
            'posted_by' => $this->careerStaff->id,
            'is_priority' => 1
        ]);

        $response = $this->actingAs($this->careerStaff)->get(route('career.dashboard'));

        $response->assertStatus(200);
        $response->assertViewHas('my_posts');
        $response->assertViewHas('categories');
        $response->assertSee('Software Intern');
    }

    /** @test */
    public function create_new_opportunity_and_save_new_category()
    {
        $data = [
            'title' => 'Junior Web Developer',
            'category' => 'Technology', // New category
            'type' => 'Part-time',
            'description' => 'Apply now!',
            'location' => 'Remote',
            'deadline' => now()->addMonth()->format('Y-m-d'),
            'is_priority' => 'on',
        ];

        $response = $this->actingAs($this->careerStaff)->post(route('opportunity.store'), $data);

        $response->assertRedirect();
        $response->assertSessionHas('msg', 'Opportunity published successfully!');

        // Check if opportunity exists
        $this->assertDatabaseHas('opportunities', [
            'title' => 'Junior Web Developer',
            'posted_by' => $this->careerStaff->id,
            'is_priority' => 1
        ]);

        // Check if category was automatically created in the categories table
        $this->assertDatabaseHas('opportunity_categories', ['name' => 'Technology']);
    }

    /** @test */
    public function fail_validation_if_miss_required_fields()
    {
        $response = $this->actingAs($this->careerStaff)->post(route('opportunity.store'), [
            'title' => '', // Required field missing
        ]);

        $response->assertSessionHasErrors(['title', 'category', 'type', 'description', 'location']);
    }

    /** @test */
    public function fail_if_deadline_is_not_valid_date()
    {
        $response = $this->actingAs($this->careerStaff)->post(route('opportunity.store'), [
            'title' => 'Valid Title',
            'category' => 'Valid Category',
            'type' => 'Full-time',
            'description' => 'Description',
            'location' => 'Location',
            'deadline' => 'not-a-date',
        ]);

        $response->assertSessionHasErrors(['deadline']);
    }

    /** @test */
    public function unauthorized_users_cannot_post_opportunities()
    {
        $student = User::factory()->create(['role' => 'Student']);

        // Middleware
        $response = $this->actingAs($student)->post(route('opportunity.store'), [
            'title' => 'Should Not Work'
        ]);
        
        $response->assertStatus(403); 
    }
}