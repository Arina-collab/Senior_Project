<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Opportunity | AUBG Portal</title>
    <link rel="stylesheet" href="{{ asset('css/Career_profile.css') }}">
</head>
<body>

<div class="sidebar">
    <h2>AUBG Portal</h2>
    <nav>
        <a href="{{ route('opportunities.add') }}">📊 Add an opportunity</a>
        <a href="{{ route('career.dashboard') }}">📋 All Postings</a>
        <a href="{{ route('career.analytics') }}">🎓 Analytics </a>
        <hr>
        <form action="{{ route('logout_btn') }}" method="POST">
            @csrf
            <button type="submit">Log Out</button>
        </form>
    </nav>
</div>

<div class="main-content">
    <div class="welcome-header">
        <h1>Edit Opportunity</h1>
        <p>Updating: <strong>{{ $opportunity->title }}</strong></p>
    </div>

    <div class="form-card">
        <form action="{{ route('opportunities.update', $opportunity->id) }}" method="POST">
            @csrf
            @method('PATCH')

            <div class="form-group">
                <label>Job Title</label>
                <input type="text" name="title" value="{{ old('title', $opportunity->title) }}" required>
            </div>

            <div class="form-group">
                <label>Company Name</label>
                <input type="text" name="company_name" value="{{ old('company_name', $opportunity->company_name) }}" required>
            </div>

            <div class="flex-row">
                <div class="form-group flex-1">
                    <label>Category</label>
                    <input type="text" name="category" value="{{ old('category', $opportunity->category) }}" required>
                </div>
                <div class="form-group flex-1">
                    <label>Job Type</label>
                    <select name="type" required>
                        <option value="Internship" {{ $opportunity->type == 'Internship' ? 'selected' : '' }}>Internship</option>
                        <option value="Full-time" {{ $opportunity->type == 'Full-time' ? 'selected' : '' }}>Full-time</option>
                        <option value="Part-time" {{ $opportunity->type == 'Part-time' ? 'selected' : '' }}>Part-time</option>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label>Location</label>
                <input type="text" name="location" value="{{ old('location', $opportunity->location) }}">
            </div>

            <div class="form-group">
                <label>Job Description</label>
                <textarea name="description" rows="6" required>{{ old('description', $opportunity->description) }}</textarea>
            </div>

            <div class="priority-box">
                <label>
                    <input type="checkbox" name="is_priority" value="1" {{ $opportunity->is_priority ? 'checked' : '' }}>
                    <span>🌟 Priority Hiring</span>
                </label>
            </div>

            <button type="submit" class="btn-submit" style="background: #003366; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer;">Update Opportunity</button>
            <a href="{{ route('career.dashboard') }}" style="margin-left: 10px; color: #666;">Cancel</a>
        </form>
    </div>
</div>
</body>
</html>