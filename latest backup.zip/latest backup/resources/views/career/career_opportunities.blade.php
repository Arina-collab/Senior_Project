<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Opportunities | AUBG Portal</title>
    <link rel="stylesheet" href="{{ asset('css/Career_opportunities.css') }}">
    <meta name="base-url" content="{{ url('/') }}">
</head>
<body>

<div class="sidebar">
    <h2>AUBG Portal</h2>
    <nav>
        <a href="{{ route('opportunities.add') }}">📊 Add an opportunity</a>

        <a href="{{ route('career.dashboard') }}" class="active">📋 All Postings</a>
        
        <a href="{{ route('career.analytics') }}">🎓 Analytics </a>
        <hr>
        <form action="{{ route('logout_btn') }}" method="POST">
            @csrf
            <button type="submit">Log Out</button>
        </form>
    </nav>
</div>

<div class="main-content">
    <div class="welcome-header">
        <h1>Career Opportunities</h1>
        <p>Here are internships, jobs, and projects that are currently visible to AUBG students.</p>
    </div>

     <div class="opportunities-wrapper">
        <aside class="filter-sidebar">
            <form action="{{ route('career.dashboard') }}" method="GET" class="filter-form">
                
                <div class="filter-group">
                    <label>Search by Keywords</label>
                    <input type="text" name="keyword" value="{{ request('keyword') }}" 
                           placeholder="e.g. Developer, Internship..." class="filter-input"
                           onkeypress="if(event.key === 'Enter') this.form.submit()">
                </div>
                
                <div class="filter-group">
                    <label>Category</label>
                    <select name="category" onchange="this.form.submit()" class="filter-select">
                        <option value="">All Categories</option>
                        @foreach($categories as $cat)
                            <option value="{{ $cat->name }}" {{ request('category') == $cat->name ? 'selected' : '' }}>
                                {{ $cat->name }}
                            </option>
                        @endforeach
                    </select>
                </div>

                <div class="filter-group">
                    <label>Location</label>
                    <input type="text" name="location" value="{{ request('location') }}" 
                           placeholder="Enter city or country..." class="filter-input" 
                           onkeypress="if(event.key === 'Enter') this.form.submit()">
                </div>

                <div class="filter-group">
                    <label class="filter-checkbox-label">
                        <input type="checkbox" name="aubg_priority" value="1" 
                               {{ request('aubg_priority') ? 'checked' : '' }} 
                               onchange="this.form.submit()">
                        AUBG Priority
                    </label>
                </div>

                @if(request()->anyFilled(['keyword', 'category', 'location', 'aubg_priority']))
                    <a href="{{ route('career.dashboard') }}" class="clear-filters">Clear All Filters</a>
                @endif
            </form>
        </aside>

        <main class="opportunities-main">
            <div class="opportunity-grid">
                @forelse($opportunities as $opp)
                    <div class="opp-card {{ $opp->is_priority ? 'priority' : '' }}">
                        <div class="card-top">
                            <div class="card-header">
                                <span class="opp-badge">{{ $opp->type }}</span>
                                @if($opp->is_priority)
                                    <span class="priority-label">⭐ Priority</span>
                                @endif
                            </div>
                            
                            <h3>{{ $opp->title }}</h3>
                            <p class="company-tag">🏢 <strong>{{ $opp->company_name }}</strong></p>
                            <p class="location-tag">📍 {{ $opp->location }} | {{ $opp->category }}</p>
                            <p class="deadline-text"><strong>Deadline:</strong> {{ $opp->deadline ?: 'No deadline set' }}</p>
                            <small class="post-date">Posted {{ $opp->created_at->diffForHumans() }}</small>

                            <div class="app-count">
                            <strong>Applicants:</strong> {{ $opp->applications_count }}
                            </div>
                        </div>
                        
                        <div class="card-footer">
                            <div class="btn-group">
                            <a href="{{ route('opportunities.show', $opp->id) }}" class="view-btn">Details</a>
                            <a href="{{ route('opportunities.edit', $opp->id) }}" class="edit-btn">
                                Edit 
                            </a>
                            <form action="{{ route('opportunities.destroy', $opp->id) }}" method="POST" style="display:inline;">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="delete-btn" onclick="return confirm('Are you sure you want to delete this opportunity?')">
                                Delete 
                                </button>
                            </form>
                        </div>
                        </div>
                    </div>
                @empty
                    <div class="empty-state">
                        <p>No opportunities found matching your criteria.</p>
                    </div>
                @endforelse
            </div>

            <div class="pagination-wrapper">
                {{ $opportunities->appends(request()->query())->links() }}
            </div>
        </main>
    </div>
</div>

<script>
    window.onclick = function(event) {
        const modal = document.getElementById('applicationModal');
        if (event.target == modal) { closeAppModal(); }
    }
</script>

</body>
</html>