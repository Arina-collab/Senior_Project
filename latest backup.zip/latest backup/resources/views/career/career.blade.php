<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Career Center Dashboard | AUBG Portal</title>
    <link rel="stylesheet" href="{{ asset('css/Career_profile.css') }}">
</head>
<body>

<div class="sidebar">
    <h2>AUBG Portal</h2>
    <nav>
        <a href="{{ route('opportunities.add') }}">📊 Add an opportunity</a>

        <a href="{{ route('career.dashboard') }}" class="active">📋 All Postings</a>
        
        <a href="{{ route('career.analytics') }}">🎓 Analytics </a>
        <hr>
        <form action="{{ route('logout_btn') }}" method="POST">
            @csrf
            <button type="submit">Log Out</button>
        </form>
    </nav>
</div>

<div class="main-content">
    <div class="welcome-header">
        <h1>Career Center Management</h1>
        <p>Post new job opportunities and internships for AUBG students.</p>
        
        @if(session('msg'))
            <div class="alert-success">{{ session('msg') }}</div>
        @endif

        @if ($errors->any())
            <div class="alert-error">
                <ul style="margin: 0;">
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
    </div>

    <div class="form-card">
        <h2>Create New Opportunity</h2>
        <form action="{{ route('opportunities.store') }}" method="POST">
            @csrf

            <div class="form-group">
                <label>Job Title</label>
                <input type="text" name="title" value="{{ old('title') }}" placeholder="e.g. Junior Data Analyst" required>
            </div>

            <div class="form-group">
            <label>Company Name</label>
            <input type="text" name="company_name" value="{{ old('company_name') }}" required>
            </div>

            <div class="flex-row">
                <div class="form-group flex-1">
                    <label>Category</label>
                    <input type="text" name="category" value="{{ old('category') }}" list="category-list" required>
                    <datalist id="category-list">
                        @foreach($categories as $cat)
                            <option value="{{ $cat->name }}">
                        @endforeach
                    </datalist>
                </div>
                <div class="form-group flex-1">
                    <label>Job Type</label>
                    <select name="type" required>
                        <option value="Internship" {{ old('type') == 'Internship' ? 'selected' : '' }}>Internship</option>
                        <option value="Full-time" {{ old('type') == 'Full-time' ? 'selected' : '' }}>Full-time</option>
                        <option value="Part-time" {{ old('type') == 'Part-time' ? 'selected' : '' }}>Part-time</option>
                    </select>
                </div>
            </div>

            <div class="flex-row">
                <div class="form-group flex-1">
                    <label>Location</label>
                    <input type="text" name="location" value="{{ old('location', 'Sofia') }}">
                </div>
                <div class="form-group flex-1">
                    <label>Application Deadline</label>
                    <input type="date" name="deadline" value="{{ old('deadline') }}">
                </div>
            </div>

            <div class="method-box">
                <h3>Application Methods</h3>
                <p class="helper-text">You must only provide an email OR a link:</p>
                <div class="flex-row">
                    <div class="form-group flex-1">
                        <label>HR Contact Email</label>
                        <input type="email" name="hr_email" value="{{ old('hr_email') }}">
                    </div>
                    <div class="form-group flex-1">
                        <label>External Application Link</label>
                        <input type="url" name="application_link" value="{{ old('application_link') }}">
                    </div>
                </div>
            </div>

            <div class="form-group">
                <label>Job Description</label>
                <textarea name="description" rows="6" required>{{ old('description') }}</textarea>
            </div>

            <div class="priority-box">
                <label class="priority-label">
                    <input type="checkbox" name="is_priority" value="1" {{ old('is_priority') ? 'checked' : '' }}>
                    <span>🌟 Mark as AUBG Priority Hiring</span>
                </label>                
            </div>

            <button type="submit" class="btn-submit">Publish Opportunity</button>
        </form>
    </div>
</div>

</body>
</html>