<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Issues | Admin</title>
    <link rel="stylesheet" href="{{ asset('css/Student_opportunities.css') }}">
    <link rel="stylesheet" href="{{ asset('css/Admin_issues.css') }}">
</head>
<body>

<div class="sidebar">
    <h2>AUBG Admin</h2>
    <nav>
        <a href="{{ route('admin.dashboard') }}">🛠 Admin Board</a>
        <a href="{{ route('admin.index') }}">🐛 Bug Reports</a>
        <hr>
        <form action="{{ route('logout_btn') }}" method="POST">@csrf<button type="submit" class="logout-link">Log Out</button></form>
    </nav>
</div>

<div class="main-content">
    @if(session('msg'))
        <div class="alert-success-banner">🎉 {{ session('msg') }}</div>
    @endif

    <div class="welcome-header">
        <h1>Student Bug Reports</h1>
        <p>Review and manage technical issues reported by students.</p>
    </div>

    <table class="admin-table">
        <thead>
            <tr>
                <th>Student</th>
                <th>Comment</th>
                <th>Screenshot</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            @foreach($issues as $issue)
            <tr>
                <td>
                    <strong>{{ $issue->user->email }}</strong><br>
                </td>
                <td style="max-width: 300px;">{{ $issue->comment }}</td>
                <td>
                    @if($issue->screenshot_path)
                        <a href="{{ asset('storage/' . $issue->screenshot_path) }}" target="_blank" style="color: #004a99; text-decoration: underline;">View Image</a>
                    @else
                        <span style="color: #ccc;">No Image</span>
                    @endif
                </td>
                <td>
                    <form action="{{ route('admin.update', $issue->id) }}" method="POST" class="update-form">
                        @csrf @method('PATCH')
                        <select name="status" onchange="this.form.submit()" class="status-badge status-{{ $issue->status }}">
                            <option value="open" {{ $issue->status == 'open' ? 'selected' : '' }}>Open</option>
                            <option value="in_progress" {{ $issue->status == 'in_progress' ? 'selected' : '' }}>In Progress</option>
                            <option value="resolved" {{ $issue->status == 'resolved' ? 'selected' : '' }}>Resolved</option>
                        </select>
                    </form>
                </td>
                <td>
                    <form action="{{ route('admin.destroy', $issue->id) }}" method="POST" onsubmit="return confirm('Delete this report forever?')">
                        @csrf @method('DELETE')
                        <button type="submit" class="action-btn delete-btn">Delete</button>
                    </form>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>

    <div style="margin-top: 20px;">
        {{ $issues->links() }}
    </div>
</div>

</body>
</html>