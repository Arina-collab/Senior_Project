<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Dashboard | AUBG Portal</title>
    <link rel="stylesheet" href="{{ asset('css/Profile.css') }}">
</head>
<body>

<div class="sidebar">
    <h2>AUBG Portal</h2>
    <p>Welcome, <strong>{{ $student_profile->first_name ?? auth()->user()->email }}</strong></p>
    <nav>
        <a href="{{ route('profile.setup') }}">🏠 Profile</a>
        <a href="{{ route('opportunities.index') }}">📢 Opportunities</a>
        <a href="{{ route('applications.index') }}">💼 Applications</a>
        <a href="{{ route('issue.create') }}">🔔 Report issues</a>
        <hr>
        <form action="{{ route('logout_btn') }}" method="POST">
            @csrf
            <button type="submit" style="background:none; color:white; border:none; cursor:pointer; font-size:16px;">Log Out</button>
        </form>
    </nav>
</div>

<div class="main-content">
    @if (!$student_profile)
        {{-- SECTION: COMPLETE PROFILE --}}
        <div class="welcome-header">
            <h1>Complete Your Profile</h1>
            @if ($errors->any())
                <div class="msg" style="color:red;">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif
        </div>

        <form action="{{ route('complete_profile_btn') }}" method="POST" style="max-width: 600px; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
            @csrf
            <label>Full Name</label>
            <div style="display:flex; gap:10px;">
                <input type="text" name="first_name" placeholder="First Name" value="{{ old('first_name') }}" required>
                <input type="text" name="second_name" placeholder="Last Name" value="{{ old('second_name') }}" required>
            </div>

            <label>Graduation Year (ex. 2026)</label>
            <input type="text" inputmode="numeric" name="graduation_year" placeholder="Graduation Year" value="{{ old('graduation_year') }}" required>
            
            <label>Phone</label>
            <input type="text" name="phone" placeholder="Phone Number" value="{{ old('phone') }}" required>

            <label>Select Majors (Max 3)</label>
            <input type="text" id="majorInput" onkeyup="filterList('majorInput', 'majorList')" placeholder="Search majors...">
            <div id="majorList" class="scroll-box">
                @foreach($major_list as $m)
                <label class="item">
                <input type="checkbox" name="majors[]" value="{{ $m->id }}">
                {{ $m->name }} 
                </label>
                @endforeach
            </div>

            <label>Select Clubs</label>
            <input type="text" id="clubInput" onkeyup="filterList('clubInput', 'clubList')" placeholder="Search clubs...">
            <div id="clubList" class="scroll-box">
                @foreach($club_list as $c)
                <label class="item">
                <input type="checkbox" name="clubs[]" value="{{ $c->id }}">
                {{ $c->name }}
            </label>
            @endforeach
            </div>

            <label>Bio</label>
            <textarea name="bio" id="bio" rows="4" maxlength="1500" onkeyup="countChars(this)">{{ old('bio') }}</textarea>
            <p id="charNum" style="font-size: 12px; color: #666;">0/1500 characters</p>

            <button type="submit">Save Profile & Continue</button>
        </form>

    @else
        {{-- SECTION: VIEW/UPDATE PROFILE --}}
        <div class="welcome-header">
            <h1>Global Paths, AUBG Roots</h1>
            <p>Welcome back, <strong>{{ $student_profile->first_name }}</strong>!</p>
            
            <div style="margin: 10px 0;">
                <strong>Current Majors:</strong> 
                @foreach($student_profile->majors as $m)
                    <span class="badge" style="background:#003366; color:white; padding:2px 8px; border-radius:10px; font-size:12px;">{{ $m->name }}</span>
                @endforeach
            </div>

            <button id="toggleUpdateBtn" onclick="showUpdateForm()" style="background:#003366; color:white; border:none; padding:10px 20px; border-radius:4px; cursor:pointer; margin-top:10px;">
                Update Profile Information
            </button>
        </div>

        <div id="updateFormSection" style="display: none; margin-top: 20px; max-width: 600px; background: #f9f9f9; padding: 30px; border-radius: 8px; border: 1px solid #ddd;">
            <h3>Update Your Details</h3>
            <form action="{{ route('profile.update') }}" method="POST">
                @csrf
                @method('PATCH')

                <label>Full Name (Contact Admin to change)</label>
                <div style="display:flex; gap:10px; margin-bottom: 15px;">
                    <input type="text" value="{{ $student_profile->first_name }}" readonly style="background-color: #e9ecef; cursor: not-allowed;">
                    <input type="text" value="{{ $student_profile->second_name }}" readonly style="background-color: #e9ecef; cursor: not-allowed;">
                </div>

                <label>Graduation Year</label>
                <input type="text" inputmode="numeric" name="graduation_year" value="{{ old('graduation_year', $student_profile->graduation_year) }}" required>

                <label>Phone Number</label>
                <input type="text" name="phone" value="{{ old('phone', $student_profile->phone) }}" required>

                <label>Update Major(s)</label>
                <div class="scroll-box" style="height:100px; overflow-y:scroll; border:1px solid #ccc; padding:10px; background:white;">
                    @foreach($major_list as $m)
                    <label class="item">
                    <input type="checkbox" name="majors[]" value="{{ $m->id }}" 
                    {{ $student_profile?->majors->contains('id', $m->id) ? 'checked' : '' }}>
                    {{ $m->name }}
                    </label>
                    @endforeach
                </div>

                <label>Update Club(s)</label>
                <div class="scroll-box" style="height:100px; overflow-y:scroll; border:1px solid #ccc; padding:10px; background:white;">
                    @foreach($club_list as $c)
                    <label class="item">
                    <input type="checkbox" name="clubs[]" value="{{ $c->id }}" 
                    {{ $student_profile?->clubs->contains('id', $c->id) ? 'checked' : '' }}>
                    {{ $c->name }} 
                    </label>
                    @endforeach
                </div>

                <label>Bio</label>
                <textarea name="bio" id="updateBio" rows="4" maxlength="1500" onkeyup="countCharsUpdate(this)">{{ old('bio', $student_profile->bio) }}</textarea>
                <p id="charNumUpdate" style="font-size: 12px; color: #666;">{{ strlen($student_profile->bio ?? '') }}/1500 characters</p>

                <button type="submit" style="background:#28a745; color:white; border:none; padding:10px 20px; border-radius:4px; cursor:pointer;">
                    Save Changes
                </button>
            </form>
        </div>

        <hr style="margin: 40px 0;">
    @endif
</div>

<script>
function countChars(obj){
    document.getElementById("charNum").innerHTML = obj.value.length + "/1500 characters";
}

function filterList(inputId, listId) {
    var input = document.getElementById(inputId);
    var filter = input.value.toUpperCase();
    var container = document.getElementById(listId);
    var labels = container.getElementsByClassName("item");

    for (var i = 0; i < labels.length; i++) {
        var textValue = labels[i].textContent || labels[i].innerText;
        labels[i].style.display = (textValue.toUpperCase().indexOf(filter) > -1) ? "" : "none";
    }
}

function countCharsUpdate(obj){
    document.getElementById("charNumUpdate").innerHTML = obj.value.length + "/1500 characters";
}

function showUpdateForm() {
    var x = document.getElementById("updateFormSection");
    var btn = document.getElementById("toggleUpdateBtn");

    if (x.style.display === "none") {
        x.style.display = "block";
        btn.innerText = "Cancel Update"; 
        btn.style.background = "#cc0000";
    } else {
        x.style.display = "none";
        btn.innerText = "Update Profile Information";
        btn.style.background = "#003366";
    }
}
</script>
</body>
</html>