<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Report an Issue | AUBG Portal</title>
    <link rel="stylesheet" href="{{ asset('css/Student_opportunities.css') }}">
    <link rel="stylesheet" href="{{ asset('css/student_issues.css') }}">
</head>
<body>

<div class="sidebar">
    <h2>AUBG Portal</h2>
    <p>Welcome, <strong>{{ auth()->user()->email }}</strong></p>
    <nav>
        <a href="{{ route('profile.setup') }}">🏠 Profile</a>
        <a href="{{ route('opportunities.index') }}">📢 Opportunities</a>
        <a href="{{ route('applications.index') }}">💼 Applications</a>
        <a href="{{ route('issue.create') }}">🔔 Report issues</a>
        <hr>
        <form action="{{ route('logout_btn') }}" method="POST">
            @csrf
            <button type="submit" class="logout-link">Log Out</button>
        </form>
    </nav>
</div>

<div class="main-content">
    
    @if(session('success'))
        <div class="alert-success-banner">
            🎉 {{ session('success') }}
        </div>
    @endif

    <div class="welcome-header">
        <h1>Report a Technical Issue</h1>
        <p>Found a bug? My team and I will check it out and fix it!</p>
    </div>

    <div class="issue-form-container">
        @if ($errors->any())
            <ul class="error-list">
                @foreach ($errors->all() as $error)
                    <li>⚠️ {{ $error }}</li>
                @endforeach
            </ul>
        @endif

        <form action="{{ route('issue.store') }}" method="POST" enctype="multipart/form-data">
            @csrf

            <div class="form-group">
                <label class="form-label">What's wrong?</label>
                <textarea 
                    name="comment" 
                    class="form-control" 
                    rows="6" 
                    placeholder="Describe the issue here... (min 20 characters)"
                >{{ old('comment') }}</textarea>
            </div>

            <div class="form-group">
                <label class="form-label">Screenshot (if you have one)</label>
                <input type="file" name="screenshot" class="form-control" accept="image/*">
                <span class="helper-text">Only JPG or PNG files. Max 2MB.</span>
            </div>

            <button type="submit" class="submit-btn">Submit</button>
        </form>
    </div>
</div>

</body>
</html>