<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>{{ $opportunity->title }} | AUBG Portal</title>
    <link rel="stylesheet" href="{{ asset('css/view_more.css') }}">
</head>
<body>

<div class="sidebar">
    <h2>AUBG Portal</h2>
    <nav>
        <a href="{{ route('profile.setup') }}">🏠 Profile</a>
        <a href="{{ route('opportunities.index') }}">📢 Opportunities</a>
        <a href="{{ route('applications.index') }}">💼 Applications</a>
        <a href="{{ route('issue.create') }}">🔔 Report issues</a>
    </nav>
</div>

<div class="main-content">
    <div class="welcome-header">
        <a href="{{ route('opportunities.index') }}" class="back-link">← Back to All Opportunities</a>
        <h1 class="page-title">{{ $opportunity->title }}</h1>
    </div>

    <div class="details-container">
        <span class="opp-badge">{{ $opportunity->type }}</span>
        
        <div class="details-meta">
            <p><strong>Company:</strong> {{ $opportunity->company_name }}</p>
            <p><strong>Location:</strong> {{ $opportunity->location }}</p>
            <p><strong>Category:</strong> {{ $opportunity->category }}</p>
            <p><strong>Deadline:</strong> {{ $opportunity->deadline ?? 'No deadline' }}</p>
        </div>

        <h3>Description</h3>
        <p class="details-description">
            {{ $opportunity->description }}
        </p>
    </div>
</div>

</body>
</html>