<x-mail::message>
# New Job Application Received

You have received a new application for the position: **{{ $application->opportunity->title }}**.

**Applicant Details:**
- **Name:** {{ $application->user->student->first_name ?? '' }} {{ $application->user->student->second_name ?? 'Applicant' }}
- **Email:** {{ $application->user->email ?? auth()->user()->email }}

**Why are they interested?**
{{ $application->q1_answer }}

**Relevant Experience:**
{{ $application->q2_answer }}

The applicant has attached their CV to this email.

Thanks,<br>
{{ config('app.name') }}
</x-mail::message>