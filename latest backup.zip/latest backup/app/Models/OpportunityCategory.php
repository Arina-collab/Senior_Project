<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OpportunityCategory extends Model
{
    // Important: match your table name since it's plural
    protected $table = 'opportunity_categories'; 
    
    protected $fillable = ['name', 'is_approved'];

    public function opportunities()
    {
        return $this->hasMany(Opportunity::class, 'category_id');
    }
}