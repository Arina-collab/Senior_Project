<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Student_Issue extends Model
{
    use HasFactory;
    protected $table = 'student_issues';

    protected $fillable = [
        'user_id',
        'comment',
        'screenshot_path',
        'browser_info',
        'status',
    ];

    /**
     * Get the student who reported the issue
     */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
    
    /**
     * Helper to get the correct img path for frontend
     */
    public function getScreenshotUrlAttribute()
    {
        return $this->screenshot_path 
            ? asset('storage/' . $this->screenshot_path) 
            : null;
    }
}