<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Student;
use App\Models\Major;
use App\Models\Club;
use App\Models\Opportunity;

class ProfileController extends Controller
{
    public function show()
    {
        $user = Auth::user();
        
        // Fetch the student with their relationships
        $student_profile = Student::with(['majors', 'clubs'])->where('user_id', $user->id)->first();

        // Fetch majors and clubs
        $major_list = Major::orderBy('name', 'asc')->get();
        $club_list = Club::orderBy('name', 'asc')->get();

        return view('student.profile', [
            'major_list' => $major_list,
            'club_list' => $club_list,
            'student_profile' => $student_profile,
            'current_year' => now()->year
        ]);
    }

    public function store(Request $request)
    {
        $current_year = now()->year;

        // Validation
        $validated = $request->validate([
            'first_name' => 'required|regex:/^[a-zA-Z\s]+$/',
            'second_name' => 'required|regex:/^[a-zA-Z\s]+$/',
            'graduation_year' => "required|integer|min:$current_year",
            'phone' => 'required|digits_between:7,15',
            'bio' => 'nullable|string|max:1500',
            'majors' => 'required|array|min:1|max:3',
            'majors.*' => 'exists:majors,id', 
            'clubs' => 'nullable|array',
            'clubs.*' => 'exists:clubs,id',
            'custom_club' => 'nullable|string|max:255',
        ]);

        // Custom Club
        $selected_club_ids = $request->input('clubs', []);
        if ($request->filled('custom_club')) {
            // Check if club already exists
            $new_club = Club::firstOrCreate(['name' => trim($request->custom_club)]);
            $selected_club_ids[] = $new_club->id;
        }

        // Create or update student record
        $student = Student::updateOrCreate(
            ['user_id' => Auth::id()],
            [
                'first_name' => $validated['first_name'],
                'second_name' => $validated['second_name'],
                'phone' => $validated['phone'],
                'graduation_year' => $validated['graduation_year'],
                'bio' => strip_tags($validated['bio']),
            ]
        );

        // Sync junction tables
        $student->majors()->sync($validated['majors']);
        $student->clubs()->sync($selected_club_ids);

        return redirect()->route('profile.setup')->with('msg', 'Profile created successfully!');
    }

    public function update(Request $request)
    {
        $current_year = now()->year;
        
        $validated = $request->validate([
            'graduation_year' => "required|integer|min:$current_year",
            'phone' => 'required|digits_between:7,15',
            'bio' => 'nullable|string|max:1500',
            'majors' => 'required|array|min:1|max:3',
            'majors.*' => 'exists:majors,id',
            'clubs' => 'nullable|array',
            'clubs.*' => 'exists:clubs,id',
        ]);

        // Get student record
        $student = Student::where('user_id', Auth::id())->firstOrFail();

        // Update table
        $student->update([
            'graduation_year' => $validated['graduation_year'],
            'phone' => $validated['phone'],
            'bio' => strip_tags($validated['bio']),
        ]);

        // Update junction tables
        $student->majors()->sync($validated['majors']);
        $student->clubs()->sync($request->input('clubs', []));

        return back()->with('msg', 'Profile updated successfully!');
    }
}