<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Student_Issue;
use Illuminate\Support\Facades\Auth;

class StudentIssuesController extends Controller
{
    // Show the form to the student
    public function create()
    {
        return view('student.student_issues');
    }

    // Save the report
    public function store(Request $request)
    {
        // Validation
        $request->validate([
            'comment'    => 'required|string|min:20', 
            'screenshot' => 'nullable|image|mimes:jpg,png,jpeg|max:2048',
        ]);

        // Screenshot upload
        $path = null;
        if ($request->hasFile('screenshot')) {
            $path = $request->file('screenshot')->store('screenshots', 'public');
        }

        // Save to db
        Student_Issue::create([
            'user_id'         => Auth::id(), 
            'comment'         => strip_tags($request->comment), 
            'screenshot_path' => $path,
            'browser_info'    => $request->userAgent(), 
            'status'          => 'open', 
        ]);

        // Redirect with a msg
        return back()->with('success', 'Issue reported! Our team will check it out.');
    }
}