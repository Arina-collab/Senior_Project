<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Application;
use Illuminate\Http\Request;
use Carbon\Carbon;

class AnalyticsController extends Controller
{
    public function index()
    {
        // Count student users
        $totalStudents = User::where('role', 'Student')->count();

        // Count all submitted applications
        $totalApplications = Application::count();

        return view('career.analytics', compact('totalStudents', 'totalApplications'));
    }

    public function getChartData(Request $request) {
    // Week offset (-1 for last week, 0 for current)
    $offset = (int) $request->query('offset', 0);
    $startOfWeek = Carbon::now()->startOfWeek()->addWeeks($offset);
    
    // Get total students to calculate percentages
    $totalStudents = User::where('role', 'Student')->count(); 

    $data = [];
    $labels = [];

    for ($i = 0; $i < 7; $i++) {
        $date = (clone $startOfWeek)->addDays($i);
        $labels[] = $date->format('D (M d)');
        // Count students by last login date
        $data[] = User::where('role', 'Student')
            ->whereDate('last_login_at', $date)
            ->count();
    }

    return response()->json([
        'labels' => $labels,
        'counts' => $data, 
        'total'  => $totalStudents, 
        'title'  => "Week of " . $startOfWeek->format('M d, Y')
    ]);
}
}