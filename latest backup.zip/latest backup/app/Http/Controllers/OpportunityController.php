<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Opportunity;
use Illuminate\Support\Facades\Auth;

class OpportunityController extends Controller
{
    //Display
    public function index()
    {
        // Fetch posts
        $my_posts = Opportunity::where('posted_by', Auth::id())
            ->orderBy('is_priority', 'desc')
            ->latest()
            ->get();

        // Get categories
        $categories = \DB::table('opportunity_categories')->where('is_approved', true)->orderBy('name', 'asc')->get();            
        
        return view('career.career', compact('my_posts', 'categories'));
    }

    //Store a new opportunity
    public function store(Request $request)
{
    // Validate
    $validated = $request->validate([
        'title'            => 'required|string|max:255',
        'company_name'     => 'required|string|max:255',
        'category'         => 'required|string|max:100',
        'type'             => 'required|string',
        'description'      => 'required|string',
        'location'         => 'required|string|max:255',
        'deadline'         => 'nullable|date|after_or_equal:today',
        'is_priority'      => 'nullable',
        // Ensures that at least one them should be provided
        'hr_email'         => 'required_without:application_link|nullable|email|max:255',
        'application_link' => 'required_without:hr_email|nullable|url|max:255',
    ], [
        // Error msg
        'hr_email.required_without' => 'You must provide either an HR Email for internal applications OR an External Application Link.',
    ]);

    // Save the category if it's new
    \DB::table('opportunity_categories')->updateOrInsert(
        ['name' => trim($request->category)],
        ['created_at' => now()]
    );

    $validated['posted_by'] = Auth::id();
    $validated['is_priority'] = $request->has('is_priority') ? 1 : 0;
    Opportunity::create($validated);
    return back()->with('msg', 'Opportunity published successfully!');
}
}