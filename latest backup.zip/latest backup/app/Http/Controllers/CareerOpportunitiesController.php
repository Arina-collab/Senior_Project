<?php

namespace App\Http\Controllers;

use App\Models\Opportunity;
use Illuminate\Http\Request;

class CareerOpportunitiesController extends Controller
{
    // Display & filter
    public function index(Request $request)
{
    $query = Opportunity::withCount('applications');

    // Keyword search
    if ($request->filled('keyword')) {
        $query->where(function ($q) use ($request) {
            $q->where('title', 'like', '%' . $request->keyword . '%')
              ->orWhere('company_name', 'like', '%' . $request->keyword . '%');
        });
    }

    // Category
    if ($request->filled('category')) {
        $query->where('category', $request->category);
    }

    // Location 
    if ($request->filled('location')) {
        $query->where('location', 'like', '%' . $request->location . '%');
    }

    // Fecth only approved categories
    $categories = \DB::table('opportunity_categories')->where('is_approved', true)->orderBy('name', 'asc')->get();

    $opportunities = $query->orderBy('is_priority', 'desc')
                           ->latest()
                           ->paginate(10);

    return view('career.career_opportunities', compact('opportunities', 'categories'));
}

    public function show(Opportunity $opportunity)
    {
        return view('career.view_more', compact('opportunity'));
    }

    // Edit
    public function edit(Opportunity $opportunity)
    {
        return view('career.edit', compact('opportunity'));
    }
    // Update
   public function update(Request $request, Opportunity $opportunity){
    $validated = $request->validate([
        'title'            => 'required|string|max:255',
        'company_name'     => 'required|string|max:255',
        'category'         => 'required|string|max:100',
        'type'             => 'required|string',
        'description'      => 'required|string',
        'location'         => 'required|string|max:255',
        'deadline'         => 'nullable|date',
        'hr_email'         => 'nullable|email|max:255',
        'application_link' => 'nullable|url|max:255',
    ]);

    // Checkbox
    $validated['is_priority'] = $request->has('is_priority');

    // Save only the validated data
    $opportunity->update($validated);

    return redirect()->route('career.dashboard')
                     ->with('success_app', 'Opportunity updated successfully!');
    }
    //Destroy
    public function destroy(Opportunity $opportunity)
    {
        $opportunity->delete();

        return redirect()->route('career.dashboard')
                         ->with('success_app', 'Opportunity deleted successfully!');
    }
}