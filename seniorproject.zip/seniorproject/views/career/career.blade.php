<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Career Center Dashboard | AUBG Portal</title>
    <link rel="stylesheet" href="{{ asset('css/Career_profile.css') }}">
</head>
<body>

<div class="sidebar">
    <h2>AUBG Portal</h2>
    <p>Staff: <strong>{{ auth()->user()->first_name ?? 'Career Center' }}</strong></p>
    <nav>
        <a href="{{ route('career.dashboard') }}">📊 Dashboard</a>
        <a href="#">📋 All Postings</a>
        <a href="#">🎓 Student Directory</a>
        <hr>
        <form action="{{ route('logout_btn') }}" method="POST">
            @csrf
            <button type="submit" style="background:none; color:white; border:none; cursor:pointer; font-size:16px;">Log Out</button>
        </form>
    </nav>
</div>

<div class="main-content">
    <div class="welcome-header">
        <h1>Career Center Management</h1>
        <p>Use this form to post new job opportunities and internships for AUBG students.</p>
        
        @if(session('msg'))
            <div style="background: #d4edda; color: #155724; padding: 15px; border-radius: 5px; margin-bottom: 20px;">
                {{ session('msg') }}
            </div>
        @endif
    </div>

    <div style="background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); max-width: 800px;">
        <h2 style="margin-top:0;">Create New Opportunity</h2>
        <form action="{{ route('opportunities.store') }}" method="POST">
            @csrf

            <div class="form-group">
                <label>Job Title</label>
                <input type="text" name="title" placeholder="e.g. Junior Data Analyst" required>
            </div>

            <div style="display:flex; gap:20px;">
                <div class="form-group" style="flex:1;">
                    <label>Category</label>
                    <select name="category" required>
                        <option value="Business">Business</option>
                        <option value="IT">IT</option>
                        <option value="Marketing">Marketing</option>
                        <option value="Finance">Finance</option>
                        <option value="Civil Society">Civil Society</option>
                        <option value="Other">Other</option>
                    </select>
                </div>
                <div class="form-group" style="flex:1;">
                    <label>Job Type</label>
                    <select name="type" required>
                        <option value="Internship">Internship</option>
                        <option value="Full-time">Full-time</option>
                        <option value="Part-time">Part-time</option>
                        <option value="Volunteering">Volunteering</option>
                    </select>
                </div>
            </div>

            <div style="display:flex; gap:20px;">
                <div class="form-group" style="flex:1;">
                    <label>Location</label>
                    <input type="text" name="location" placeholder="e.g. Sofia, Remote, or Campus" value="Sofia">
                </div>
                <div class="form-group" style="flex:1;">
                    <label>Application Deadline</label>
                    <input type="date" name="deadline">
                </div>
            </div>

            <div class="form-group">
                <label>Job Description</label>
                <textarea name="description" rows="6" placeholder="Describe the role, requirements, and how to apply..." required></textarea>
            </div>

            <div class="priority-box">
                <label style="display: flex; align-items: center; gap: 10px; cursor: pointer;">
                    <input type="checkbox" name="is_priority" value="1" style="width:20px; height:20px;">
                    <span style="font-weight: bold; color: #b38f00;">🌟 Mark as AUBG Priority Hiring</span>
                </label>
                <p style="font-size: 13px; color: #666; margin: 5px 0 0 30px;">
                    This will highlight the post and keep it at the top of the student feed.
                </p>
            </div>

            <button type="submit" style="background: #003366; color: white; padding: 12px 25px; border: none; border-radius: 4px; cursor: pointer; font-weight: bold; width: 100%;">
                Publish Opportunity
            </button>
        </form>
    </div>

    <hr style="margin: 40px 0; border: 0; border-top: 1px solid #eee;">

    <h2>Your Recent Postings</h2>
    <div class="opportunity-list">
        @forelse($my_posts as $post)
            <div class="card" style="margin-bottom: 15px; border-left: 5px solid {{ $post->is_priority ? '#b38f00' : '#ccc' }}">
                <div style="display: flex; justify-content: space-between;">
                    <h3>{{ $post->title }}</h3>
                    @if($post->is_priority)
                        <span class="badge-priority">🌟 Priority</span>
                    @endif
                </div>
                <p style="margin: 5px 0;">
                    <strong>{{ $post->category }}</strong> | {{ $post->type }} | {{ $post->location }}
                </p>
                <p style="color: #666; font-size: 14px;">{{ Str::limit($post->description, 120) }}</p>
                <div style="margin-top: 10px; font-size: 12px; color: #888;">
                    Deadline: {{ $post->deadline ?? 'No deadline' }}
                </div>
            </div>
        @empty
            <p>You haven't posted any opportunities yet.</p>
        @endforelse
    </div>
</div>

</body>
</html>