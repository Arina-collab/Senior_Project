<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Opportunities | AUBG Portal</title>
    <link rel="stylesheet" href="{{ asset('css/Student_opportunities.css') }}">
</head>
<body>

<div class="sidebar">
    <h2>AUBG Portal</h2>
    <p>Welcome, <strong>{{ auth()->user()->email }}</strong></p>
    <nav>
        <a href="{{ route('profile.setup') }}">🏠 Profile</a>
        <a href="#">🔔 Notifications</a>
        <a href="{{ route('opportunities.index') }}">📢 Opportunities</a>
        <a href="#">📅 Events</a>
        <a href="#">💼 Applications</a>
        <a href="#">📄 Registrations</a>
        <a href="#">✅ Poster Approval</a>
        <hr>
        <form action="{{ route('logout_btn') }}" method="POST">
            @csrf
            <button type="submit" class="logout-link">Log Out</button>
        </form>
    </nav>
</div>

<div class="main-content">
    <div class="welcome-header">
        <h1>Career Opportunities</h1>
        <p>Explore internships, jobs, and projects available for AUBG students.</p>
    </div>

    <div class="filter-section">
        <form action="{{ route('opportunities.index') }}" method="GET" class="filter-form">
            <div class="filter-group">
                <label>Filter by Category:</label>
                <select name="category" onchange="this.form.submit()" class="filter-select">
                    <option value="">All Categories</option>
                    @foreach($categories as $cat)
                        <option value="{{ $cat->name }}" {{ request('category') == $cat->name ? 'selected' : '' }}>
                            {{ $cat->name }}
                        </option>
                    @endforeach
                </select>
            </div>
            @if(request('category'))
                <a href="{{ route('opportunities.index') }}" class="clear-filters">Clear Filters</a>
            @endif
        </form>
    </div>

    <div class="opportunity-grid">
        @forelse($opportunities as $opp)
            <div class="opp-card {{ $opp->is_priority ? 'priority' : '' }}">
                <div class="card-top">
                    <div class="card-header">
                        <span class="opp-badge">{{ $opp->type }}</span>
                        @if($opp->is_priority)
                            <span class="priority-label">⭐ Priority</span>
                        @endif
                    </div>
                    
                    <h3>{{ $opp->title }}</h3>
                    <p class="location-tag">📍 {{ $opp->location }} | {{ $opp->category }}</p>
                    <p class="deadline-text"><strong>Deadline:</strong> {{ $opp->deadline ?: 'No deadline set' }}</p>
                </div>
                
                <div class="card-footer">
                    <small class="post-date">Posted {{ $opp->created_at->diffForHumans() }}</small>
                    <a href="{{ route('opportunities.show', $opp->id) }}" class="view-btn">View Details</a>
                </div>
            </div>
        @empty
            <div class="empty-state">
                <p>No opportunities found matching your criteria.</p>
            </div>
        @endforelse
    </div>

    <div class="pagination-wrapper">
        {{ $opportunities->appends(request()->query())->links() }}
    </div>
</div>

</body>
</html>