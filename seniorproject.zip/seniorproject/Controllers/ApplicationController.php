<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB; 

class ApplicationController extends Controller
{
    public function apply(Request $request, $id) {
    // Validate
    $request->validate([
        'q1_answer' => 'required|string|min:10|max:5000',
        'q2_answer' => 'required|string|min:10|max:5000',
        'cv'        => 'required|file|mimes:pdf|max:2048', 
    ]);

    // Check if the student has already applied for this opportunity
    $existingApplication = DB::table('applications')
        ->where('opportunity_id', $id)
        ->where('student_id', Auth::id())
        ->exists();

    if ($existingApplication) {
        return back()->with('error_app', 'You have already applied for this opportunity.');
    }

    // File Upload
    $path = $request->file('cv')->store('resumes', 'public');

    // Save Application
    DB::table('applications')->insert([
        'opportunity_id' => $id,
        'student_id'     => Auth::id(),
        'q1_answer'      => $request->q1_answer,
        'q2_answer'      => $request->q2_answer,
        'cv_path'        => $path,
        'created_at'     => now(),
        'updated_at'     => now(),
    ]);

    return back()->with('success_app', 'Your application was submitted successfully!');
    }
}