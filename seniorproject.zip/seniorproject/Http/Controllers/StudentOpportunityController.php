<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Opportunity; 
use Illuminate\Support\Facades\DB;

class StudentOpportunityController extends Controller
{
    public function index(Request $request)
{
    $query = Opportunity::query();

    // Only filter by category if user selected it in the dropdown
    if ($request->filled('category')) {
        $query->where('category', $request->category);
    }

    $opportunities = $query->orderBy('is_priority', 'desc')
                           ->latest()
                           ->paginate(10);

    $categories = \DB::table('opportunity_categories')->orderBy('name', 'asc')->get();

    return view('student.opportunities', compact('opportunities', 'categories'));
}

public function show($id)
{
    // Find the opportunity or fail with a 404 error if not found
    $opportunity = Opportunity::findOrFail($id);

    return view('student.view_more', compact('opportunity'));
}
}