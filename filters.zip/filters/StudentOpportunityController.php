<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Opportunity; 
use Illuminate\Support\Facades\DB;

class StudentOpportunityController extends Controller
{
   public function index(Request $request)
{
    $query = Opportunity::query();

    // Filter by Category
    if ($request->filled('category')) {
        $query->where('category', $request->category);
    }

    // Filter by Location (partial search included)
    if ($request->filled('location')) {
        $query->where('location', 'LIKE', '%' . $request->location . '%');
    }

    // Filter by AUBG Priority
    if ($request->has('aubg_priority')) {
        $query->where('is_priority', true);
    }

    // Sorting
    $opportunities = $query->orderBy('deadline', 'asc') // Sooner deadlines first
                           ->orderBy('is_priority', 'desc')
                           ->paginate(10);

    // Fetch categories for the dropdown
    $categories = \DB::table('opportunity_categories')->orderBy('name', 'asc')->get();

    return view('student.opportunities', compact('opportunities', 'categories'));
}

public function show($id)
{
    // Find the opportunity or fail with a 404 error if not found
    $opportunity = Opportunity::findOrFail($id);

    return view('student.view_more', compact('opportunity'));
}
}